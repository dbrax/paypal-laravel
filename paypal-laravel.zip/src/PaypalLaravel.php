<?php

namespace Epmnzava\PaypalLaravel;

class PaypalLaravel
{
    // Build your next great package.
}
